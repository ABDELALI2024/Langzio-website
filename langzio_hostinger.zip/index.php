<?php
$pageTitle = "Langzio - Cultural AI for Darija";
$pageDescription = "Darija translation with cultural context, verified phrase packs, and family-friendly learning — built for Morocco travelers and diaspora.";
$pageClass = "landing-page";
include "includes/head.php";
?>

<header class="top-nav container glass">
    <a class="brand" href="index.php">Langzio</a>
    <nav>
        <a href="#why">Why Langzio</a>
        <a href="#features">Features</a>
        <a href="#beta">Beta</a>
        <a class="nav-cta" href="translator.php">Try Free</a>
    </nav>
</header>

<main>
    <section class="hero container">
        <span class="badge">Early beta · Morocco + diaspora</span>
        <h1>Darija with context, not just translation</h1>
        <p>Google Translate misses slang, tone, and culture. Langzio gives you natural Darija phrases, when to use them, and what to avoid — for trips and for families keeping the language alive abroad.</p>
        <div class="hero-cta">
            <a class="btn btn-primary" href="kids.php?challenge=1">Start 7-Day Challenge</a>
            <a class="btn btn-secondary" href="translator.php">Try Translator</a>
        </div>
        <div class="hero-metrics honest-metrics">
            <div><strong>28</strong><span>Verified phrase packs</span></div>
            <div><strong>4</strong><span>Situational guides</span></div>
            <div><strong>Beta</strong><span>Free while we learn</span></div>
        </div>
    </section>

    <section class="features container" id="why">
        <h2>Built for real Moroccan conversations</h2>
        <p class="section-lead">Most apps translate words. Langzio translates <em>situations</em> — restaurant, souk, taxi, family visits — with etiquette baked in.</p>
        <div class="feature-grid">
            <article class="card">
                <h3>Structured Translator</h3>
                <p>Darija + pronunciation + tone + cultural tip. Not a wall of text.</p>
            </article>
            <article class="card">
                <h3>Verified Phrase RAG</h3>
                <p>AI grounded in curated Darija packs before it improvises.</p>
            </article>
            <article class="card">
                <h3>Cultural Chat</h3>
                <p>Ask about etiquette, slang, and social nuance with conversation memory.</p>
            </article>
            <article class="card">
                <h3>Diaspora Kids</h3>
                <p>Flashcards and streaks so children stay connected to Darija abroad.</p>
            </article>
        </div>
    </section>

    <section class="demo container" id="features">
        <div class="section-title">
            <h2>What a good answer looks like</h2>
            <p>Every translation aims for clarity, respect, and practical use.</p>
        </div>
        <div class="demo-mockup glass structured-preview">
            <div class="structured-card">
                <div class="structured-row"><span>Darija</span><strong>3afak, jib lia l7sab.</strong></div>
                <div class="structured-row"><span>Say it</span><strong>afak, jib liya l-ḥsab</strong></div>
                <div class="structured-row"><span>Meaning</span><strong>Please bring me the bill.</strong></div>
                <div class="structured-row"><span>Tone</span><strong>Polite / neutral</strong></div>
                <div class="structured-row"><span>Tip</span><strong>Smile + "3afak" goes a long way in cafés.</strong></div>
            </div>
        </div>
    </section>

    <section class="beta-section container" id="beta">
        <div class="card beta-card">
            <h2>Join the beta</h2>
            <p>We're building Langzio with travelers and Moroccan families abroad. Get early access updates — no spam.</p>
            <form class="waitlist-form" id="waitlistForm">
                <input type="email" id="waitlistEmail" placeholder="you@email.com" required>
                <button class="btn btn-primary" type="submit">Join waitlist</button>
            </form>
            <p class="waitlist-feedback hidden" id="waitlistFeedback"></p>
        </div>
    </section>

    <section class="testimonials container">
        <h2>Who it's for</h2>
        <div class="testimonial-grid">
            <blockquote class="card">
                <strong>Tourists</strong>
                <p>Navigate restaurants, souks, and taxis with phrases locals actually use.</p>
            </blockquote>
            <blockquote class="card">
                <strong>MRE families</strong>
                <p>Help kids learn Darija with bite-sized practice between visits home.</p>
            </blockquote>
            <blockquote class="card">
                <strong>Digital nomads</strong>
                <p>Understand context and tone — not just dictionary definitions.</p>
            </blockquote>
        </div>
    </section>
</main>

<footer class="site-footer container">
    <div>
        <strong>Langzio</strong>
        <p>Cultural language intelligence for Darija.</p>
    </div>
    <div class="footer-links">
        <a href="translator.php">Translator</a>
        <a href="chat.php">AI Chat</a>
        <a href="guides.php">Guides</a>
        <a href="kids.php">Kids</a>
    </div>
    <p class="copyright">© <?php echo date("Y"); ?> Langzio · Early beta</p>
</footer>

<?php include "includes/footer.php"; ?>
