<?php
require_once __DIR__ . "/classes/Auth.php";
Auth::startSession();
$user = Auth::user();
$subStatus = Auth::subscriptionStatus();

$pageTitle = "Pricing — Langzio";
$pageDescription = "Upgrade your Langzio experience with Pro.";
$pageClass = "app-page";
include "includes/head.php";
?>

<div class="app-shell container">
    <aside class="sidebar glass">
        <a class="brand" href="index.php">Langzio</a>
        <button class="nav-toggle" id="navToggle" type="button">☰</button>
        <nav class="side-nav">
            <a href="dashboard.php">Dashboard</a>
            <a href="translator.php">Translator</a>
            <a href="chat.php">AI Chat</a>
            <a href="guides.php">Guides</a>
            <a href="kids.php">Kids</a>
            <hr style="border-color:rgba(255,255,255,0.08);margin:12px 0">
            <a href="profile.php">Profile</a>
            <a class="active" href="pricing.php">Pricing</a>
            <a href="logout.php">Log out</a>
        </nav>
    </aside>

    <main class="app-content">
        <header class="app-topbar glass">
            <h1>Choose your plan</h1>
        </header>

        <section class="dashboard-grid" style="grid-template-columns:repeat(auto-fit,minmax(260px,1fr))">
            <article class="card" style="text-align:center;padding:28px">
                <h3>Free</h3>
                <p style="font-size:2rem;font-weight:800;margin:12px 0">$0</p>
                <ul style="list-style:none;padding:0;text-align:left;color:var(--muted)">
                    <li>✓ Limited translations</li>
                    <li>✓ Basic chat</li>
                    <li>✓ Kids flashcards</li>
                </ul>
                <?php if ($user && $subStatus["plan"] === "free"): ?>
                    <span class="badge" style="margin-top:16px">Current plan</span>
                <?php else: ?>
                    <a class="btn btn-secondary" href="<?php echo htmlspecialchars(langzio_url($user ? 'dashboard.php' : 'register.php')); ?>" style="margin-top:16px;display:inline-block">
                        <?php echo $user ? "Current plan" : "Start free"; ?>
                    </a>
                <?php endif; ?>
            </article>

            <article class="card" style="text-align:center;padding:28px;border-color:var(--green);background:rgba(0,211,139,0.06)">
                <span class="badge">Popular</span>
                <h3>Pro</h3>
                <p style="font-size:2rem;font-weight:800;margin:12px 0">$9<span style="font-size:1rem;color:var(--muted)">/month</span></p>
                <ul style="list-style:none;padding:0;text-align:left;color:var(--muted)">
                    <li>✓ Unlimited translations</li>
                    <li>✓ Unlimited AI chat</li>
                    <li>✓ Cultural insights</li>
                    <li>✓ All guides & flashcards</li>
                    <li>✓ Priority support</li>
                </ul>
                <?php if ($subStatus["plan"] === "pro"): ?>
                    <span class="badge" style="margin-top:16px">Active</span>
                <?php elseif ($user): ?>
                    <div id="paypal-button-container" style="margin-top:16px"></div>
                <?php else: ?>
                    <a class="btn btn-primary" href="<?php echo htmlspecialchars(langzio_url('register.php')); ?>" style="margin-top:16px;display:inline-block">Start free trial</a>
                <?php endif; ?>
            </article>
        </section>

        <section class="card" style="text-align:center">
            <h2>Start with a free trial</h2>
            <p style="color:var(--muted)">7 days full access. No credit card needed.</p>
            <a class="btn btn-primary" href="<?php echo htmlspecialchars(langzio_url('register.php')); ?>">Create free account</a>
        </section>
    </main>
</div>

<script src="https://www.paypal.com/sdk/js?client-id=<?php echo htmlspecialchars(langzio_env('PAYPAL_CLIENT_ID', 'test')); ?>&vault=true&intent=subscription" data-sdk-integration-source="button-factory"></script>
<script>
document.addEventListener("DOMContentLoaded", () => {
    const container = document.getElementById("paypal-button-container");
    if (!container || typeof paypal === "undefined") return;

    paypal.Buttons({
        style: {
            shape: "rect",
            color: "gold",
            layout: "vertical",
            label: "subscribe"
        },
        createSubscription: function(data, actions) {
            return actions.subscription.create({
                plan_id: "<?php echo htmlspecialchars(langzio_env('PAYPAL_PLAN_ID', '')); ?>"
            });
        },
        onApprove: async function(data) {
            const resp = await fetch("<?php echo htmlspecialchars(langzio_url('api/paypal/subscription-approve.php')); ?>", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ subscriptionID: data.subscriptionID })
            });
            const result = await resp.json();
            if (result.success) {
                window.location.href = "<?php echo htmlspecialchars(langzio_url('dashboard.php')); ?>";
            } else {
                alert("Subscription activation failed. Please contact support.");
            }
        },
        onError: function(err) {
            alert("PayPal error: " + err.message);
        }
    }).render("#paypal-button-container");
});
</script>

<?php include "includes/footer.php"; ?>
