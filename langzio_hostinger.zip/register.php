<?php
require_once __DIR__ . "/classes/Auth.php";
Auth::startSession();

$error = "";
$success = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $name     = trim($_POST["name"] ?? "");
    $email    = trim($_POST["email"] ?? "");
    $password = $_POST["password"] ?? "";
    $confirm  = $_POST["password_confirm"] ?? "";

    if ($name === "" || $email === "" || $password === "") {
        $error = "All fields are required.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = "Invalid email address.";
    } elseif (strlen($password) < 8) {
        $error = "Password must be at least 8 characters.";
    } elseif ($password !== $confirm) {
        $error = "Passwords do not match.";
    } else {
        $existing = User::findByEmail($email);
        if ($existing) {
            $error = "An account with this email already exists.";
        } else {
            $user = User::create($name, $email, $password);
            Subscription::createTrial((int) $user["id"]);
            Auth::login((int) $user["id"]);

            try {
                $whatsapp = new WhatsAppNotificationService();
                $trialDays = (int) langzio_env("TRIAL_DAYS", "7");
                $whatsapp->welcome((int) $user["id"], $user["name"], $trialDays);
                $whatsapp->trialStarted((int) $user["id"], $user["name"], date("Y-m-d", strtotime("+{$trialDays} days")));
            } catch (\Exception $e) {
                error_log("WhatsApp welcome failed: " . $e->getMessage());
            }

            if (langzio_env("MAIL_ENABLED", "false") === "true") {
                require_once __DIR__ . "/classes/EmailService.php";
                EmailService::sendVerification($email, $name, $user["verification_token"]);
            }

            $redirect = langzio_url("dashboard.php");
            header("Location: " . $redirect);
            exit;
        }
    }
}

Auth::redirectIfLoggedIn();

$pageTitle = "Register — Langzio";
$pageDescription = "Create your free Langzio account.";
$pageClass = "auth-page";
include "includes/head.php";
?>
<main class="auth-card">
    <div class="auth-logo">L</div>
    <h1>Create account</h1>
    <p class="auth-subtitle">7-day free trial &mdash; no credit card required</p>

    <?php if ($error): ?>
        <div class="form-feedback form-error"><?php echo htmlspecialchars($error); ?></div>
    <?php endif; ?>
    <?php if ($success): ?>
        <div class="form-feedback form-success"><?php echo htmlspecialchars($success); ?></div>
    <?php endif; ?>

    <form method="post" class="auth-form">
        <label>
            Name
            <input type="text" name="name" required autocomplete="name"
                   value="<?php echo htmlspecialchars($_POST["name"] ?? ""); ?>">
        </label>
        <label>
            Email
            <input type="email" name="email" required autocomplete="email" inputmode="email"
                   value="<?php echo htmlspecialchars($_POST["email"] ?? ""); ?>">
        </label>
        <label>
            Password
            <input type="password" name="password" required minlength="8" autocomplete="new-password">
        </label>
        <label>
            Confirm password
            <input type="password" name="password_confirm" required minlength="8" autocomplete="new-password">
        </label>
        <button class="btn btn-primary" type="submit" style="width:100%;margin-top:8px">Create account</button>
    </form>

    <p class="auth-footer">
        Already have an account?
        <a href="<?php echo htmlspecialchars(langzio_url('login.php')); ?>">Log in</a>
    </p>
</main>
<?php include "includes/footer.php"; ?>
