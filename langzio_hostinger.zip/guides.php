<?php
require_once __DIR__ . "/classes/Auth.php";
Auth::requireLogin();
$user = Auth::user();
$subStatus = Auth::subscriptionStatus();

$pageTitle = "Langzio Smart Guides";
$pageDescription = "Category guides for key Morocco situations.";
$pageClass = "app-page";
include "includes/head.php";
?>

<div class="app-shell container">
    <aside class="sidebar glass">
        <a class="brand" href="index.php">Langzio</a>
        <button class="nav-toggle" id="navToggle" type="button">☰</button>
        <nav class="side-nav">
            <a href="dashboard.php">Dashboard</a>
            <a href="translator.php">Translator</a>
            <a href="chat.php">AI Chat</a>
            <a class="active" href="guides.php">Guides</a>
            <a href="kids.php">Kids</a>
            <hr style="border-color:rgba(255,255,255,0.08);margin:12px 0">
            <a href="profile.php">Profile</a>
            <a href="pricing.php">Pricing</a>
            <a href="logout.php">Log out</a>
        </nav>
        <div style="margin-top:auto;padding:12px;border-radius:10px;background:rgba(0,211,139,0.08);font-size:0.85rem;text-align:center">
            <?php if ($subStatus["is_trial"]): ?>
                <strong>Trial</strong> &mdash; <?php echo $subStatus["days_remaining"]; ?> day(s) left
            <?php elseif ($subStatus["is_subscribed"]): ?>
                <strong>Pro</strong> &mdash; Active
            <?php else: ?>
                <a href="pricing.php" style="color:var(--green-2)">Upgrade to Pro</a>
            <?php endif; ?>
        </div>
    </aside>

    <main class="app-content">
        <header class="app-topbar glass">
            <h1>Smart Guides</h1>
            <a class="btn btn-secondary compact" href="dashboard.php">Dashboard</a>
        </header>
        <p style="margin: -10px 0 20px; color: var(--text-dim, #aaa); font-size: 0.9rem;">Salam, <?php echo htmlspecialchars($user["name"]); ?></p>

        <section class="card guides-intro">
            <h2>Morocco Phrase Playbooks</h2>
            <p>Use these practical packs in real situations. Each guide includes high-value phrases, what they mean, and quick etiquette notes so you can sound natural and respectful.</p>
            <div class="guides-toolbar">
                <input id="guidesSearch" type="text" placeholder="Search phrase or meaning (ex: bill, taxi, shukran)">
                <div class="guides-feedback" id="guidesFeedback">Browse all phrase packs.</div>
            </div>
        </section>

        <section class="guide-grid">
            <article class="card guide-card">
                <h3>Restaurant</h3>
                <p>Order politely, ask for recommendations, and request the bill naturally.</p>
                <div class="guide-section">
                    <h4>Essential Phrases</h4>
                    <ul>
                        <li><strong>Salam, wach kayn blassa?</strong> - Hello, is there a table available?</li>
                        <li><strong>Shno katnsa7ni?</strong> - What do you recommend?</li>
                        <li><strong>3afak, bghit had lplat.</strong> - Please, I would like this dish.</li>
                        <li><strong>3afak, jib lia l7sab.</strong> - Please bring me the bill.</li>
                    </ul>
                </div>
                <div class="guide-tip">Tip: "3afak" (please) instantly makes your tone warmer and more local.</div>
            </article>
            <article class="card guide-card">
                <h3>Souk</h3>
                <p>Negotiate respectfully, compare prices, and close deals with confidence.</p>
                <div class="guide-section">
                    <h4>Essential Phrases</h4>
                    <ul>
                        <li><strong>Bchhal hadchi?</strong> - How much is this?</li>
                        <li><strong>Ghaliya chwiya.</strong> - It's a bit expensive.</li>
                        <li><strong>A3tini taman lakhir.</strong> - Give me your final price.</li>
                        <li><strong>Safi, ntafa9na.</strong> - Great, we have a deal.</li>
                    </ul>
                </div>
                <div class="guide-tip">Tip: Bargaining is normal in many souks, but stay friendly and smile.</div>
            </article>
            <article class="card guide-card">
                <h3>Taxi</h3>
                <p>Confirm destination, agree on fare, and avoid confusion before the ride starts.</p>
                <div class="guide-section">
                    <h4>Essential Phrases</h4>
                    <ul>
                        <li><strong>3afak, l medina.</strong> - Please, to the medina.</li>
                        <li><strong>Bchhal lprix?</strong> - How much is the fare?</li>
                        <li><strong>Dir compteur, 3afak.</strong> - Please use the meter.</li>
                        <li><strong>Waqaf hna, 3afak.</strong> - Stop here, please.</li>
                    </ul>
                </div>
                <div class="guide-tip">Tip: Confirm the price before entering when meter use is unclear.</div>
            </article>
            <article class="card guide-card">
                <h3>Family</h3>
                <p>Use warm expressions for greetings, gratitude, and respectful visits.</p>
                <div class="guide-section">
                    <h4>Essential Phrases</h4>
                    <ul>
                        <li><strong>Labas 3likom?</strong> - How are you all?</li>
                        <li><strong>Allah ykhalikom.</strong> - May God bless/protect you.</li>
                        <li><strong>Shukran bzzaf.</strong> - Thank you very much.</li>
                        <li><strong>Mtsharfin b ziyartkom.</strong> - We are honored by your visit.</li>
                    </ul>
                </div>
                <div class="guide-tip">Tip: Family settings value politeness and appreciation more than perfect grammar.</div>
            </article>
        </section>

        <section class="card guides-cheatsheet">
            <h2>Quick Etiquette Cheatsheet</h2>
            <div class="cheatsheet-grid">
                <div>
                    <h4>Do</h4>
                    <ul>
                        <li>Start conversations with "Salam".</li>
                        <li>Use "3afak" when requesting help.</li>
                        <li>Thank often: "Shukran".</li>
                    </ul>
                </div>
                <div>
                    <h4>Avoid</h4>
                    <ul>
                        <li>Using a very direct tone without greeting.</li>
                        <li>Assuming all prices are fixed in souks.</li>
                        <li>Rushing social interactions with elders.</li>
                    </ul>
                </div>
            </div>
        </section>

        <section class="card guides-favorites">
            <h2>Saved Favorites</h2>
            <p>Your starred phrases are stored in this browser.</p>
            <ul id="favoritePhrases"></ul>
        </section>
    </main>
</div>

<?php include "includes/footer.php"; ?>
