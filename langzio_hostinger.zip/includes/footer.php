<script>window.LANGZIO_BASE = <?php echo json_encode(langzio_base_path(), JSON_UNESCAPED_SLASHES); ?>;</script>
<script>document.addEventListener("DOMContentLoaded",function(){var n=document.querySelector(".side-nav"),t=document.getElementById("navToggle");if(n&&t){window.innerWidth<=768&&n.classList.remove("open");t.addEventListener("click",function(){n.classList.toggle("open")})}});</script>
<?php include __DIR__ . "/onboarding.php"; ?>
<script src="<?php echo htmlspecialchars(langzio_url('assets/js/app.js'), ENT_QUOTES, 'UTF-8'); ?>"></script>
</body>
</html>
