<?php
require_once __DIR__ . "/../config.php";

if (!isset($pageTitle)) {
    $pageTitle = "Langzio - AI Language Companion";
}
if (!isset($pageDescription)) {
    $pageDescription = "Langzio helps tourists and Moroccan diaspora translate Darija, understand culture, and communicate naturally.";
}
if (!isset($pageClass)) {
    $pageClass = "";
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
<meta name="mobile-web-app-capable" content="yes">
<meta name="format-detection" content="telephone=no">
    <meta name="description" content="<?php echo htmlspecialchars($pageDescription, ENT_QUOTES, 'UTF-8'); ?>">
    <meta name="keywords" content="Darija translator, Morocco travel AI, Moroccan culture assistant, MRE app">
    <meta name="author" content="Langzio">
    <meta name="theme-color" content="#00a76f">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-title" content="Langzio">
    <link rel="manifest" href="<?php echo htmlspecialchars(langzio_url('manifest.php'), ENT_QUOTES, 'UTF-8'); ?>">
    <link rel="icon" href="<?php echo htmlspecialchars(langzio_url('assets/icon.svg'), ENT_QUOTES, 'UTF-8'); ?>" type="image/svg+xml">
    <title><?php echo htmlspecialchars($pageTitle, ENT_QUOTES, 'UTF-8'); ?></title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo htmlspecialchars(langzio_url('assets/css/style.css'), ENT_QUOTES, 'UTF-8'); ?>?v=2.0">
</head>
<body class="<?php echo htmlspecialchars($pageClass, ENT_QUOTES, 'UTF-8'); ?>">
<div class="bg-orb orb-1"></div>
<div class="bg-orb orb-2"></div>
