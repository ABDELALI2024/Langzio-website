<?php
http_response_code(404);
$pageTitle = "404 - Page Not Found";
$pageDescription = "The page you are looking for does not exist.";
$pageClass = "auth-page";
include "includes/head.php";
?>

<main class="auth-card" style="text-align:center">
    <div class="auth-logo" style="font-size:2rem">404</div>
    <h1 style="margin-bottom:8px">Page not found</h1>
    <p style="color:var(--muted);margin-bottom:20px">The page you are looking for does not exist or has been moved.</p>
    <a class="btn btn-primary" href="<?php echo htmlspecialchars(langzio_url('index.php')); ?>" style="display:inline-block">Back to Home</a>
    <div style="margin-top:12px">
        <a class="btn btn-secondary" href="<?php echo htmlspecialchars(langzio_url('dashboard.php')); ?>" style="display:inline-block">Dashboard</a>
    </div>
</main>

<?php include "includes/footer.php"; ?>
