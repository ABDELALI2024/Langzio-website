<?php
require_once __DIR__ . "/classes/Auth.php";
Auth::requireLogin();
$user = Auth::user();
$subStatus = Auth::subscriptionStatus();

$pageTitle = "Langzio Translator";
$pageDescription = "Translate Darija and Moroccan phrases with AI context.";
$pageClass = "app-page";
include "includes/head.php";
?>

<div class="app-shell container">
    <aside class="sidebar glass">
        <a class="brand" href="index.php">Langzio</a>
        <button class="nav-toggle" id="navToggle" type="button">☰</button>
        <nav class="side-nav">
            <a href="dashboard.php">Dashboard</a>
            <a class="active" href="translator.php">Translator</a>
            <a href="chat.php">AI Chat</a>
            <a href="guides.php">Guides</a>
            <a href="kids.php">Kids</a>
            <hr style="border-color:rgba(255,255,255,0.08);margin:12px 0">
            <a href="profile.php">Profile</a>
            <a href="pricing.php">Pricing</a>
            <a href="logout.php">Log out</a>
        </nav>
        <div style="margin-top:auto;padding:12px;border-radius:10px;background:rgba(0,211,139,0.08);font-size:0.85rem;text-align:center">
            <?php if ($subStatus["is_trial"]): ?>
                <strong>Trial</strong> &mdash; <?php echo $subStatus["days_remaining"]; ?> day(s) left
            <?php elseif ($subStatus["is_subscribed"]): ?>
                <strong>Pro</strong> &mdash; Active
            <?php else: ?>
                <a href="pricing.php" style="color:var(--green-2)">Upgrade to Pro</a>
            <?php endif; ?>
        </div>
    </aside>

    <main class="app-content">
        <header class="app-topbar glass">
            <h1>AI Translator</h1>
            <a class="btn btn-secondary compact" href="dashboard.php">Dashboard</a>
        </header>

        <section class="card translator-card">
            <div class="translator-header">
                <select id="sourceLang">
                    <option value="english">English</option>
                    <option value="darija">Darija</option>
                    <option value="french">French</option>
                </select>
                <button class="swap-btn" id="swapLang" type="button">⇄</button>
                <select id="targetLang">
                    <option value="darija">Darija</option>
                    <option value="english">English</option>
                    <option value="french">French</option>
                </select>
            </div>

            <div class="translator-panels">
                <textarea id="translatorInput" placeholder="Type your phrase..."></textarea>
                <div class="translator-result" id="translatorResult">
                    <textarea id="translatorOutput" placeholder="Translation appears here..." readonly></textarea>
                    <div class="structured-output hidden" id="structuredOutput"></div>
                </div>
            </div>

            <button class="btn btn-primary pulse" id="translateBtn" type="button">Translate with AI</button>
            <div class="loading hidden" id="translatorLoading"><span class="spinner"></span> Translating...</div>
        </section>
    </main>
</div>

<?php include "includes/footer.php"; ?>
