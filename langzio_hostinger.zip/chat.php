<?php
require_once __DIR__ . "/classes/Auth.php";
Auth::requireLogin();
$user = Auth::user();
$subStatus = Auth::subscriptionStatus();

$pageTitle = "Langzio AI Chat";
$pageDescription = "Chat with AI about Moroccan language and culture.";
$pageClass = "app-page";
include "includes/head.php";
?>

<div class="app-shell container">
    <aside class="sidebar glass">
        <a class="brand" href="index.php">Langzio</a>
        <button class="nav-toggle" id="navToggle" type="button">☰</button>
        <nav class="side-nav">
            <a href="dashboard.php">Dashboard</a>
            <a href="translator.php">Translator</a>
            <a class="active" href="chat.php">AI Chat</a>
            <a href="guides.php">Guides</a>
            <a href="kids.php">Kids</a>
            <hr style="border-color:rgba(255,255,255,0.08);margin:12px 0">
            <a href="profile.php">Profile</a>
            <a href="pricing.php">Pricing</a>
            <a href="logout.php">Log out</a>
        </nav>
        <div style="margin-top:auto;padding:12px;border-radius:10px;background:rgba(0,211,139,0.08);font-size:0.85rem;text-align:center">
            <?php if ($subStatus["is_trial"]): ?>
                <strong>Trial</strong> &mdash; <?php echo $subStatus["days_remaining"]; ?> day(s) left
            <?php elseif ($subStatus["is_subscribed"]): ?>
                <strong>Pro</strong> &mdash; Active
            <?php else: ?>
                <a href="pricing.php" style="color:var(--green-2)">Upgrade to Pro</a>
            <?php endif; ?>
        </div>
    </aside>

    <main class="app-content">
        <header class="app-topbar glass">
            <h1>Cultural AI Chat</h1>
            <button class="btn btn-secondary compact" id="clearChatBtn" type="button">Clear History</button>
        </header>

        <section class="chat-shell card">
            <div class="chat-messages" id="chatMessages">
                <div class="message ai">Salam! I can help you with Darija phrases and Moroccan social etiquette.</div>
            </div>
            <div class="typing hidden" id="chatTyping"><span></span><span></span><span></span></div>
            <div class="chat-input-row">
                <input id="chatInput" type="text" placeholder="Ask anything about Morocco...">
                <button class="btn btn-primary" id="sendChatBtn" type="button">Send</button>
            </div>
        </section>
    </main>
</div>

<?php include "includes/footer.php"; ?>
