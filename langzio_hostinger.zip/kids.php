<?php
require_once __DIR__ . "/classes/Auth.php";
Auth::requireLogin();
$user = Auth::user();
$subStatus = Auth::subscriptionStatus();

$pageTitle = "Langzio Kids — 7-Day Darija Challenge";
$pageDescription = "Help your children learn Darija with flashcards, streaks, and a 7-day family challenge.";
$pageClass = "app-page kids-page";
include "includes/head.php";
?>

<div class="app-shell container">
    <aside class="sidebar glass">
        <a class="brand" href="index.php">Langzio</a>
        <button class="nav-toggle" id="navToggle" type="button">☰</button>
        <nav class="side-nav">
            <a href="dashboard.php">Dashboard</a>
            <a href="translator.php">Translator</a>
            <a href="chat.php">AI Chat</a>
            <a href="guides.php">Guides</a>
            <a class="active" href="kids.php">Kids</a>
            <hr style="border-color:rgba(255,255,255,0.08);margin:12px 0">
            <a href="profile.php">Profile</a>
            <a href="pricing.php">Pricing</a>
            <a href="logout.php">Log out</a>
        </nav>
        <div style="margin-top:auto;padding:12px;border-radius:10px;background:rgba(0,211,139,0.08);font-size:0.85rem;text-align:center">
            <?php if ($subStatus["is_trial"]): ?>
                <strong>Trial</strong> &mdash; <?php echo $subStatus["days_remaining"]; ?> day(s) left
            <?php elseif ($subStatus["is_subscribed"]): ?>
                <strong>Pro</strong> &mdash; Active
            <?php else: ?>
                <a href="pricing.php" style="color:var(--green-2)">Upgrade to Pro</a>
            <?php endif; ?>
        </div>
    </aside>

    <main class="app-content">
        <header class="app-topbar glass">
            <h1>7-Day Darija Challenge</h1>
            <button class="btn btn-secondary compact" id="installAppBtn" type="button">Install app</button>
        </header>

        <section class="card challenge-card">
            <div class="challenge-header">
                <div>
                    <h2>Family challenge</h2>
                    <p id="challengeStatus">Practice 5 words a day for 7 days.</p>
                </div>
                <div class="challenge-badge hidden" id="challengeBadge"></div>
            </div>
            <div class="challenge-days" id="challengeDays"></div>
            <div class="challenge-progress">
                <div class="challenge-bar"><span id="challengeBarFill"></span></div>
                <p id="challengeToday">Today: 0 / 5 words</p>
            </div>
        </section>

        <section class="card kids-card">
            <div class="kids-stats">
                <span>🔥 Streak: <strong id="kidsStreak">0</strong> days</span>
                <span>⭐ Learned: <strong id="kidsLearned">0</strong></span>
            </div>
            <h2>Flashcards</h2>
            <div class="flashcard" id="flashcardWord">Salam = Hello</div>
            <div class="hero-cta">
                <button class="btn btn-primary" id="nextFlashcardBtn" type="button">Next Word</button>
                <button class="btn btn-secondary" id="speakWordBtn" type="button">Play Sound</button>
                <button class="btn btn-secondary" id="shareWordBtn" type="button">Share</button>
            </div>
            <p class="kids-note">Built for Moroccan families abroad — 5 words daily keeps Darija alive between visits home.</p>
        </section>
    </main>
</div>

<?php include "includes/footer.php"; ?>
