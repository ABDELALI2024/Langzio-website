<?php
require_once __DIR__ . "/classes/Auth.php";
require_once __DIR__ . "/classes/User.php";

Auth::startSession();
$message = "";

$token = $_GET["token"] ?? "";
if ($token !== "") {
    $user = User::findByVerificationToken($token);
    if ($user) {
        User::verifyEmail((int) $user["id"]);
        $message = "Email verified successfully!";
        if (Auth::id() === null) {
            Auth::login((int) $user["id"]);
        }
    } else {
        $message = "Invalid or expired verification link.";
    }
} else {
    $message = "No verification token provided.";
}

$pageTitle = "Verify Email — Langzio";
$pageClass = "auth-page";
include "includes/head.php";
?>
<main class="auth-card" style="text-align:center">
    <div class="auth-logo">L</div>
    <h1 style="margin-bottom:16px"><?php echo htmlspecialchars($message); ?></h1>
    <?php if (str_contains($message, "success")): ?>
        <p style="color:var(--green-2);margin-bottom:8px">✓ Your email is verified</p>
    <?php endif; ?>
    <a class="btn btn-primary" href="<?php echo htmlspecialchars(langzio_url('dashboard.php')); ?>" style="display:inline-block;margin-top:8px">Go to Dashboard</a>
</main>
<?php include "includes/footer.php"; ?>
