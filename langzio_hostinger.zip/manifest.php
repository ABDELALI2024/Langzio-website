<?php
require_once __DIR__ . "/../config.php";
header("Content-Type: application/manifest+json; charset=utf-8");

$start = langzio_url("dashboard.php");
$icon = langzio_url("assets/icon.svg");

echo json_encode([
    "name" => "Langzio — Darija Companion",
    "short_name" => "Langzio",
    "description" => "Darija translation, cultural chat, and family learning.",
    "start_url" => $start,
    "scope" => langzio_base_path() === "" ? "/" : langzio_base_path() . "/",
    "display" => "standalone",
    "background_color" => "#060b0a",
    "theme_color" => "#00a76f",
    "icons" => [
        ["src" => $icon, "sizes" => "any", "type" => "image/svg+xml", "purpose" => "any"],
    ],
], JSON_UNESCAPED_SLASHES);
